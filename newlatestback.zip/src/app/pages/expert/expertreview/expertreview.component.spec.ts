import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpertreviewComponent } from './expertreview.component';

describe('ExpertreviewComponent', () => {
  let component: ExpertreviewComponent;
  let fixture: ComponentFixture<ExpertreviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpertreviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpertreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

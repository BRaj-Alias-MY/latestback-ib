export class Feedback {
  interviewUserQuestionId: number;
  id: number;
  review: string;
  rating: string ;
}

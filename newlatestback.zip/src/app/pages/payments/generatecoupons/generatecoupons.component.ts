import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import {GridOptions} from "ag-grid-community";
import { ChildMessageRenderer } from '../../../childmessagerender.component';
import { ValidationService } from '../../../services/validation.service';
import {PaymentsService} from '../../payments/services/payments.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-generatecoupons',
  templateUrl: './generatecoupons.component.html',
  styleUrls: ['./generatecoupons.component.css']
})
export class GeneratecouponsComponent implements OnInit {
  up_val : any;
  index = '';
  rpt_btn_name = '';
  update;
  items;
  btn_update = 'Update';
  btn_add = 'Add';
  access ;
  selectedDevice;
  IsForUpdate: boolean = false;    
  newItem: any = {};    
  updatedItem; 
  btn_name: string;  
  current_page : number;
  start_record : number;
  pages;
  total_records: number;
  grid_tab = []; 
  sh_add: boolean;
  coupon: boolean;
  togel_name: string;
  view_item= [];
  private gridOptions: GridOptions;
	private gridApi;
	private gridColumnApi;

	private columnDefs;
	private rowData;
	private context;
	private frameworkComponents;

  constructor(private fb: FormBuilder, private route: Router, private api : PaymentsService) {
    this.gridOptions = <GridOptions>{
			paginationNumberFormatter: function(params) {
				return '[' + params.value.toLocaleString() + ']';
			}
		};
		this.columnDefs = [
      { headerName: 'Coupon Type', field: 'type' },
      { headerName: 'Code', field: 'code' },
      { headerName: 'Discount', field: 'discount' },
      { headerName: 'Expiry Date', field: 'expDate' },
			{
				headerName: 'Action',
				cellRenderer: 'childMessageRenderer',
				colId: 'params',
				value: 'id'
			}
		];
		this.frameworkComponents = {
			childMessageRenderer: ChildMessageRenderer
		};
		this.context = { componentParent: this };
   }

  ngOnInit() {
    this.sh_add = false;
    this.coupon = false;
    this.togel_name = 'Add';
    this.btn_name = 'Save';
    this.view_item = [];
    this.current_page = 1;
    this.pages = [];
    this.start_record = 1;
    this.update = false;
    this.access = [];
    this.rpt_btn_name = this.btn_add;
    this.up_val = '';
    this.grid();

  }
couponsForm = this.fb.group({
    id:[],
    type: [''],
    code: [''],
    discount: [''],
    expDate: [''],
    no_of_coupans:['',ValidationService.numericValidator]
 });

 
  add_togel() {
    this.sh_add = this.sh_add ? false : true;
    this.togel_name = this.togel_name == 'Add' ? 'Close' : 'Add';
    this.btn_name = 'Save';
    this.couponsForm.patchValue({ type: '',code: '',discount: '',expDate: '',no_of_coupans: '' });
  }

  onChange($event){
    console.log(this.selectedDevice);
    if(this.selectedDevice == "discount")
    {
      this.coupon = this.coupon ? false : true;
    }
    else{
      this.coupon = this.coupon ? false : false;
    }

  }

  onSubmit(){
     console.log(this.couponsForm.value);
      this.api.generate_coupons(this.couponsForm.value).subscribe((res) => {
        if (res.status) {
          this.couponsForm.patchValue({ type: '', code: '' });
          this.grid();
          this.sh_add=false;
          Swal.fire('Success..', 'Coupons Were Sucessfully Generated.', 'success');
          // this.clear_fields();
        } else {
          //this.loading.hide();
          Swal.fire('Oops...', 'Something went wrong!', 'error');
        }
      });
    
  }

  grid(){
    this.api.get_coupons().subscribe((data) => {
      this.access = data.access;
     
			if (this.access && this.access.gridAccess) {
        this.grid_tab = data.data;
        console.log(this.grid_tab);
			}
			this.sh_add = false;
			this.togel_name = 'Add';
			this.btn_name = 'Save';
			//this.loading.hide();
			this.view_item = [];
		});
  }

}

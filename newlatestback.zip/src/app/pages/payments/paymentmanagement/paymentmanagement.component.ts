import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import {GridOptions} from "ag-grid-community";
import { ChildMessageRenderer } from '../../../childmessagerender.component';
import { ValidationService } from '../../../services/validation.service';
import {PaymentsService} from '../../payments/services/payments.service';
import {ApiService} from '../../../services/api.service';
import Swal from 'sweetalert2/dist/sweetalert2.js'


@Component({
  selector: 'app-paymentmanagement',
  templateUrl: './paymentmanagement.component.html',
  styleUrls: ['./paymentmanagement.component.css']
})
export class PaymentmanagementComponent implements OnInit {
  user_role;
  up_val : any;
  index = '';
  rpt_btn_name = '';
  update;
  items;
  btn_update = 'Update';
  btn_add = 'Add';
  access ;
  selectedDevice;
  IsForUpdate: boolean = false;    
  newItem: any = {};    
  updatedItem; 
  btn_name: string;  
  current_page : number;
  start_record : number;
  pages;
  total_records: number;
  grid_tab = []; 
  sh_add: boolean;
  coupon: boolean;
  togel_name: string;
  view_item= [];
  organization;
  paymenttypes;
  total = 0;
  result = 0;
  org;
  cheque;
  bank;  
  maxinits;
  private gridOptions: GridOptions;
	private gridApi;
	private gridColumnApi;

	private columnDefs;
	private rowData;
	private context;
	private frameworkComponents;

  userdetails : any;
  constructor(private fb: FormBuilder, private route: Router, private api : PaymentsService, private apinew : ApiService) { }
  interviews;
  ngOnInit() {
    this.sh_add = false;
    this.coupon = false;
    this.togel_name = 'Add';
    this.btn_name = 'Save';
    this.view_item = [];
    this.current_page = 1;
    this.pages = [];
    this.start_record = 1;
    this.update = false;
    this.access = [];
    this.rpt_btn_name = this.btn_add;
    this.up_val = '';
    this.api.get_organization().subscribe(res=> this.organization = res.data);
    this.api.get_interviewtypes().subscribe(res=> this.paymenttypes = res.data);
    this.btn_name = 'Check Out for Paypal';
    if(this.apinew.getUser()){
      let user = this.apinew.getUser()
      this.user_role = user.roleId;
      if(this.user_role == 1 || this.user_role ==2)
      {
        this.org = true;
        this.cheque = true;
        this.bank = true;
        this.btn_name = 'Proceed';
        this.maxinits = true;
        this.paymentmanagementForm.patchValue({paymentMode:'cheque'});
      }else if(this.user_role == 4){
        this.org = false;
        this.cheque = false;
        this.bank = false;
        this.paymentmanagementForm.patchValue({organization:user.orginationId});
        this.paymentmanagementForm.patchValue({paymentMode:'paypal'});
        this.maxinits = true;
      }else{
        this.org = false;
        this.cheque = false;
        this.bank = false;
        this.maxinits = false;
        this.paymentmanagementForm.patchValue({paymentMode:'paypal'});
      }
    
    }
  }
  paymentmanagementForm = this.fb.group({
    id:[],
    organization: [''],
    interviews: ['',ValidationService.numericValidator],
    startDate: [''],
    paymentMode:[''],
    couponCode:[''],
    cost:[''],
    total:[''],
    interviewtype:[''],
    maxInterviews:['',ValidationService.numericValidator],
    days:['',ValidationService.numericValidator],
    chequeNo:['',ValidationService.numericValidator],
    bankName:['',ValidationService.alphaValidator]
 });


 
 add_togel() {
  this.sh_add = this.sh_add ? false : true;
  this.togel_name = this.togel_name == 'Add' ? 'Close' : 'Add';
  this.paymentmanagementForm.patchValue({ question: '' });
}

onChange(){

   let intcount = this.paymentmanagementForm.value.interviews;
   if(intcount == '')
   {
    //Swal.fire('Please Enter Number of Interviews First!', 'error');
    //Swal.fire('', 'Please Enter Number of Interviews!!', 'error');
    //this.paymentmanagementForm.patchValue({ interviewtype: '' });


   }
   else{
   let inttypo = this.paymentmanagementForm.value.interviewtype;
 let tto=0;
  for (let i = 0; i < inttypo.length; i++) {
   // console.log(this.paymentmanagementForm.value.interviewtype);
   tto += intcount * inttypo[i].price;
   
}
this.total = tto;
this.result = this.total;
//console.log(this.total);
//this.paymentmanagementForm.value.cost = this.total;
this.paymentmanagementForm.patchValue({ cost: this.total });
this.paymentmanagementForm.patchValue({ total: this.total });

   }


}

onChange1(){
console.log(this.total);
let coupon = this.paymentmanagementForm.value.couponCode;
this.api.get_discountval(coupon).subscribe((res) => {
  if (res.status) {
   // console.log(res);
    let couponamt = res.data.discount;
    //console.log(couponamt);
    this.result = this.total - (this.total*couponamt)/100;
    this.paymentmanagementForm.patchValue({ total: this.result });

    //Swal('Success..', 'Record insert/updated successfully.', 'success');
    // this.clear_fields();
  } else {
    alert('Fail');
    //Swal('Oops...', 'Something went wrong!', 'error');
  }
});
//console.log(this.result);
}

onSubmit(){
  console.log(this.paymentmanagementForm.value);
   this.api.savepayment(this.paymentmanagementForm.value).subscribe((res) => {
     if (res.status && res.message=='redirect') {
       console.log(res.data.id);
       this.route.navigate(['/main/payment'], { queryParams: { id: res.data.id }});
      // this.paymentmanagementForm.patchValue({ id: '', question: '' });
       //this.grid();
       // this.clear_fields();
     } else if(res.status) {
       //this.loading.hide(); 
       Swal.fire('Success..', 'Your Payment is Sucessful', 'success');
      }
      else{
        Swal.fire('Oops...', 'Something went wrong!', 'error');

      }
   });
 
}




}

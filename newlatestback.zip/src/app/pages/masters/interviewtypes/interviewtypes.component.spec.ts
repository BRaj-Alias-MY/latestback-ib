import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewtypesComponent } from './interviewtypes.component';

describe('InterviewtypesComponent', () => {
  let component: InterviewtypesComponent;
  let fixture: ComponentFixture<InterviewtypesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterviewtypesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterviewtypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

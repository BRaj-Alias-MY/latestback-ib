import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { MastersService } from '../services/masters.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { ValidationService } from '../../../services/validation.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer } from '../../../childmessagerender.component';

@Component({
	selector: 'app-expertlevel',
	templateUrl: './expertlevel.component.html',
	styleUrls: [ './expertlevel.component.css' ]
})
export class ExpertlevelComponent implements OnInit {
	up_val: any;
	index = '';
	rpt_btn_name = '';
	update;
	items;
	lenght;
	btn_update = 'Update';
	btn_add = 'Add';
	access;
	IsForUpdate: boolean = false;
	newItem: any = {};
	updatedItem;
	btn_name: string;
	current_page: number;
	start_record: number;
	pages;
	total_records: number;
	grid_tab = [];
	sh_add: boolean;
	togel_name: string;
	view_item= [];
	private gridOptions: GridOptions;
	private gridApi;
	private gridColumnApi;

	private columnDefs;
	private rowData;
	private context;
	private frameworkComponents;
	constructor(private fb: FormBuilder, private route: Router, private api: MastersService) {
		this.gridOptions = <GridOptions>{
			paginationNumberFormatter: function(params) {
				return '[' + params.value.toLocaleString() + ']';
			}
		};
		this.columnDefs = [
			{ headerName: 'Experience', field: 'experiance' },
			{
				headerName: 'Action',
				cellRenderer: 'childMessageRenderer',
				colId: 'params',
				value: 'id'
			}
		];
		this.frameworkComponents = {
			childMessageRenderer: ChildMessageRenderer
		};
		this.context = { componentParent: this };
	}

	ngOnInit() {
		this.sh_add = false;
		this.togel_name = 'Add';
		this.btn_name = 'Save';
		this.view_item = [];
		this.current_page = 1;
		this.pages = [];
		this.start_record = 1;
		this.update = false;
		this.access = {addAccess: 0, editAccess: 0,deleteAccess:0,gridAccess:0};
		this.rpt_btn_name = this.btn_add;
		this.up_val = '';
		this.grid();
	}
	onEditClick(id) {
		console.log(id);
	}

	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;

		params.api.sizeColumnsToFit();
	}
	expertlevelForm = this.fb.group({
		id:[],
		experiance: ['']
	});

	add_togel() {
		this.sh_add = this.sh_add ? false : true;
		this.togel_name = this.togel_name == 'Add' ? 'Close' : 'Add';
		this.btn_name = 'Save';
		this.expertlevelForm.patchValue({ experiance: '' });
	}

	methodFromParentEdit(cell,valls) {
		// Swal("Edit");
		 console.log(valls.id);
		 this.EditItem(valls.id)
	   }
	   EditItem(item_id)
	   {
		// console.log(item_id);
		 this.sh_add = true;
		 this.togel_name = 'Close';
		 this.btn_name = 'Update';
		 this.expertlevelForm.patchValue(this.get_item_data_with_id(item_id));
		// this.organization= this.get_item_data_with_id(item_id).organization_campuses;
	 //console.log( this.organization);
	   }
	   get_item_data_with_id(item_id){
		for(let i=0;i<this.grid_tab.length;i++){
		  if(this.grid_tab[i].id==item_id){
			return this.grid_tab[i];
		  }
		}
	  }
	 
	   methodFromParentView(cell,valls) {
	   // Swal("View");
		 console.log(valls);
		 this.ViewItem(valls.id)
	   }
	
	   ViewItem(item_id)
	   {
		 this.view_item.push(this.get_item_data_with_id(item_id));
		 //console.log(this.view_item);
		 this.sh_add = false;
		 this.togel_name = 'Add';
	   }
	 
	   back_view(){
		 this.view_item = [];
	   }
	

	onSubmit() {
		// this.domainForm.value.domain = this.domain;
		if (this.expertlevelForm.value.id>0) {
			//alert('hi');
			this.api.expert_level_update(this.expertlevelForm.value).subscribe((res) => {
				if (res.status) {
					this.expertlevelForm.patchValue({ id: '', experiance: ''});
		   this.grid();
		   this.sh_add = false;
		   Swal.fire('Success..', 'Record insert/updated successfully.', 'success');

				} else {
					//this.loading.hide();
					Swal.fire('Oops...', 'Something went wrong!', 'error');
				}
			});
		} else {
			console.log(this.expertlevelForm.value);
			this.api.add_expertlevel(this.expertlevelForm.value).subscribe((res) => {
				if (res.status) {
					this.expertlevelForm.patchValue({ id: '', experiance: '' });
					this.grid();
					this.sh_add=false;
					Swal.fire('Success..', 'Record insert/updated successfully.', 'success');
					// this.clear_fields();
				} else {
					//this.loading.hide();
					Swal.fire('Oops...', 'Please enter Valid Data!', 'error');
				}
			});
		}
	}

	grid() {
		//console.log(this.current_page);
		this.api.get_expert_data().subscribe((data) => {
			this.access = data.access;
			//console.log(this.access);
			if (this.access && this.access.gridAccess) {
				// console.log("Hello world");
				this.grid_tab = data.data;
				//console.log(this.grid_tab.length);
				this.pages = Array.apply(null, { length: this.access.total_pages }).map(Number.call, Number);
				//console.log(this.pages);
				this.start_record = (this.access.current_page - 1) * this.access.limit + 1;
				this.total_records = this.access.total_records;
			}
			this.sh_add = false;
			this.togel_name = 'Add';
			this.btn_name = 'Save';
			//this.loading.hide();
			this.view_item = [];
		});
	}
}

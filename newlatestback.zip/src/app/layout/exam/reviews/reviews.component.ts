import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

import { ChartType } from 'chart.js';
import { AppService } from '../../../app.service';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';
@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css']
})
export class ReviewsComponent implements OnInit {
  // PolarArea

  public polarAreaChartLabels: string[] = ['Download Sales', 'In-Store Sales', 'Mail Sales', 'Telesales'];
  public polarAreaChartData: any = [5, 6, 7, 8, 9, 10];
  public polarAreaLegend = true;
  reviewId = localStorage.getItem('vid');
  public polarAreaChartType: ChartType = 'polarArea';
  mydata = [];
  constructor(private service: AppService) { }

  ngOnInit() {
    this.getReviews();

  }
  getReviews() {
    this.service.getReviews(this.reviewId).subscribe(resp => { console.log(resp); this.mydata = resp; }, err => console.log(err));
  }

  public generatePDF() {
    var data = document.getElementById('contentToConvert');
    html2canvas(data).then(canvas => {
      // Few necessary setting options 
      var imgWidth = 208;
      var pageHeight = 295;
      var imgHeight = canvas.height * imgWidth / canvas.width;
      var heightLeft = imgHeight;

      const contentDataURL = canvas.toDataURL('image/png')
      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF 
      var position = 0;
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
      pdf.save('MYPdf.pdf'); // Generated PDF  
    });
  }


  // events
  public chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

  public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

}
